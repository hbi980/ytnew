#pragma once

#include <windows.h>

#include <string>
using namespace std;

class CYTBase64
{
public:
	CYTBase64(void);
	~CYTBase64(void);

	static string Encode(const string& str);
	static string Decode(const string& str);

	static string& GetDelimiter(void)
	{
		static string delimiter = "\r\n";
		return delimiter;
	}
	static const char* GetEnBase64Table(void)
	{
		static const char EnBase64Table[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
		return EnBase64Table;
	}
	static const char* GetDeBase64Table(void)
	{
		static const char DeBase64Table[] =
		{
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			62,        // '+'
			0, 0, 0,
			63,        // '/'
			52, 53, 54, 55, 56, 57, 58, 59, 60, 61,        // '0'-'9'
			0, 0, 0, 0, 0, 0, 0,
			0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12,
			13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25,        // 'A'-'Z'
			0, 0, 0, 0, 0, 0,
			26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38,
			39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51,        // 'a'-'z'
		};
		return DeBase64Table;
	}

public:
// Encode
	enum { _MAX_LINE_LENGTH = 72 };
	static size_t DoEncode(const char* pSrc, size_t nSrcLen, char* pDst)
	{
		// ����Ҳ���Կ������䵽unicode��
		const size_t nMaxLineLen = _MAX_LINE_LENGTH;
		BYTE c1, c2, c3;    // ���뻺��������3���ֽ�
		size_t nDstLen = 0;             // ������ַ�����
		size_t nLineLen = 0;            // ������г��ȼ���
		size_t nDiv = nSrcLen / 3;      // �������ݳ��ȳ���3�õ��ı���
		size_t nMod = nSrcLen % 3;      // �������ݳ��ȳ���3�õ�������
		const char* EnBase64Tab = GetEnBase64Table();
		// ÿ��ȡ3���ֽڣ������4���ַ�
		for (size_t i = 0; i < nDiv; i ++)
		{
			// ȡ3���ֽ�
			c1 = *pSrc++;
			c2 = *pSrc++;
			c3 = *pSrc++;
			// �����4���ַ�
			*pDst++ = EnBase64Tab[c1 >> 2];
			*pDst++ = EnBase64Tab[((c1 << 4) | (c2 >> 4)) & 0x3f];
			*pDst++ = EnBase64Tab[((c2 << 2) | (c3 >> 6)) & 0x3f];
			*pDst++ = EnBase64Tab[c3 & 0x3f];
			nLineLen += 4;
			nDstLen += 4;
			// ������У�
			if(nLineLen > nMaxLineLen - 4)
			{
				const string& delimiter = GetDelimiter();
				std::copy(delimiter.begin(), delimiter.end(), pDst);
				nLineLen = 0;
				nDstLen += delimiter.size();
			}
		}
		// �������µ��ֽ�
		if(nMod == 1)
		{
			c1 = *pSrc++;
			*pDst++ = EnBase64Tab[(c1&0xfc)>>2];
			*pDst++ = EnBase64Tab[((c1&0x03)<<4)];
			*pDst++ = '=';
			*pDst++ = '=';
			nLineLen += 4;
			nDstLen += 4;
		}
		else if(nMod == 2)
		{
			c1 = *pSrc++;
			c2 = *pSrc++;
			*pDst++ = EnBase64Tab[(c1 & 0xfc)>>2];
			*pDst++ = EnBase64Tab[((c1 & 0x03)<<4) | ((c2&0xf0)>>4)];
			*pDst++ = EnBase64Tab[((c2 & 0x0f)<<2)];
			*pDst++ = '=';
			nDstLen += 4;
		}
		return nDstLen;
	}

	static size_t DoDecode(const char* pSrc, size_t nSrcLen, char* pDst)
	{
		size_t nValue;             // �����õ��ĳ�����
		size_t nDstLen = 0;
		size_t i = 0;
		// ȡ4���ַ������뵽һ�����������پ�����λ�õ�3���ֽ�
		const char* DeBase64Tab = GetDeBase64Table();
		while(i < nSrcLen)
		{
			if(*pSrc!='\r' && *pSrc!='\n')
			{
				nValue = DeBase64Tab[*pSrc++] << 18;
				nValue += DeBase64Tab[*pSrc++] << 12;
				*pDst++ = (nValue & 0x00ff0000) >> 16;
				nDstLen++;
				if(*pSrc != '=')
				{
					nValue += DeBase64Tab[*pSrc++] << 6;
					*pDst++ = (nValue & 0x0000ff00) >> 8;
					nDstLen++;
					if(*pSrc != '=')
					{
						nValue += DeBase64Tab[*pSrc++];
						*pDst++ =nValue & 0x000000ff;
						nDstLen++;
					}
				}
				i += 4;
			}
			else        // �س����У�����
			{
				pSrc++;
				i++;
			}
		}
		return nDstLen;
	}

private:
	static size_t calcEnoughEncodedLength(size_t length)
	{
		size_t len = length/3;
		if(length%3 > 0)
		{
			++len;
		}
		len *= 4;
		size_t line = len/_MAX_LINE_LENGTH;
		if(len%_MAX_LINE_LENGTH > 0)
		{
			++line;
		}
		len += line*2;
		return len;
	}

	static size_t calcEnoughDecodedLength(size_t length)
	{
		return length;
	}

private:
	static BYTE getFirstSixBits(BYTE val)
	{
		return (val&0xFC)>>2;
	}
	static BYTE getLastSixBits(BYTE val)
	{
		return val&0x3F;
	}
};

inline string CYTBase64::Encode(const string& str)
{
	string result;
	size_t size = calcEnoughEncodedLength(str.size());
	if(size > 0)
	{
		result.resize(size);
		size_t len = DoEncode(str.data(), str.size(), &result[0]);
		result.resize(len);
	}
	return result;
}

inline string CYTBase64::Decode(const string& str)
{
	string result;
	size_t size = calcEnoughDecodedLength(str.size());
	if(size > 0)
	{
		result.resize(size);
		size_t len = DoDecode(str.data(), str.size(), &result[0]);
		result.resize(len);
	}
	return result;
}