/*
* Copyright (c) 2014, WinTech
* All rights reserved.
*
* �ļ����ƣ�YTUnit.h
* �ļ�ժҪ��ͨ�ò������װ
*
* Dll�޸ģ� 2015-05-29 saimen�޸� V1.0
*
*/
#pragma once

#pragma warning(disable : 4786)
#pragma warning(disable : 4996)

#include "YTBase64.h"
#include "YTLoopCrypt.h"
#include "YTBlowfish.h"
#include "YTMd5.h"
#include "YTCompress.h"
#include "YTCrc.h"
#include "YTFile.h"
#include "YTIniFile.h"
#include "YTLogFile.h"
#include "YTLock.h"
#include "YTMutex.h"
#include "YTSemaphore.h"
#include "YTEvent.h"
#include "YTSocket.h"
#include "YTThread.h"
#include "YTDll.h"

#pragma comment(lib, "../../../YTPublic/YTInclude/YTUnit/YTUnit.lib")